const { LOCALE } = require("../util/EvobotUtil");
const i18n = require("i18n");
const { MessageEmbed } = require("discord.js");

i18n.setLocale(LOCALE);

module.exports = {
  name: "invite",
  description: i18n.__('invite.description'),
  execute(message, args) {
    var permissions = 70282305;

    let invite1 = new MessageEmbed()
      .setTitle(`**Here is the Invite Link **`)
      .setDescription(
        `**You Cannot Invite Me! Due to Discord Rules. 
        Just Join Valenzuela City RP Discord! Thanks.**`
      )
      .setURL(
        `https://discord.gg/Q2qYvkw5as`
      )
      .setColor("RANDOM");
    return message.channel.send(invite1);
  }
};
